const giftScreen = document.getElementById('gift-screen');
const greetingScreen = document.getElementById('greeting-screen');
const choiceScreen = document.getElementById('choice-screen');
const answer = document.getElementById('answer');
const confettiLayer = document.getElementById('confetti');

function showScreen(screen) {
  document.querySelectorAll('.screen').forEach(item => item.classList.remove('active'));
  screen.classList.add('active');
}

function celebrate(amount = 90) {
  const colors = ['#ff65a3', '#ffe47a', '#9b72ff', '#75e6da', '#ffffff'];
  for (let i = 0; i < amount; i++) {
    const piece = document.createElement('span');
    piece.className = 'confetti';
    piece.style.left = `${Math.random() * 100}%`;
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDelay = `${Math.random() * 1.2}s`;
    piece.style.animationDuration = `${2.2 + Math.random() * 2}s`;
    piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    confettiLayer.appendChild(piece);
    setTimeout(() => piece.remove(), 5000);
  }
}

document.getElementById('open-gift').addEventListener('click', () => {
  showScreen(greetingScreen);
  celebrate(150);
  // Show the birthday wishes for five seconds, then move to the gift choices.
  setTimeout(() => showScreen(choiceScreen), 5000);
});

const replies = {
  money: 'Oke 😁😁',
  clothes: 'Tuje kapde miljayenge, magar muje teri saheliya 🙃🙃',
  nothing: 'Sahi kiya, vaise bhi is gareeb se kya hi expect kr skte h 😂'
};

document.querySelectorAll('.choice').forEach(button => {
  button.addEventListener('click', () => {
    answer.textContent = replies[button.dataset.answer];
    celebrate(45);
  });
});

document.getElementById('replay').addEventListener('click', () => {
  answer.textContent = '';
  showScreen(giftScreen);
});
